package com.haris.kareem.InterfaceUtil;

public interface CategoryCallback {

    void categoryCallback(int parentPosition,int childPosition);

}
