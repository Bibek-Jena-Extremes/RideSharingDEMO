package com.haris.kareem.InterfaceUtil;

public interface OrderCallback {

    void onOrderClickListener(int position);



}
