package com.haris.kareem.InterfaceUtil;

public interface LocationCallback {

    void onLocationSelectedListener(int position);



}
