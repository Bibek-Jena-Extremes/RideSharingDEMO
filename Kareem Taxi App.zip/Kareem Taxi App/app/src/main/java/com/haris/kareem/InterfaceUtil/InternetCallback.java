package com.haris.kareem.InterfaceUtil;

public interface InternetCallback {

    void onConnectivityFailed();

}
