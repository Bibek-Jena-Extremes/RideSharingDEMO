package com.haris.kareem.ObjectUtil;

public class InternetObject {
}
